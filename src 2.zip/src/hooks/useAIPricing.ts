/**
 * 💰 useAIPricing Hook
 *
 * React Query hook for fetching and managing AI model pricing data
 */

import { useQuery, useQueryClient } from '@tanstack/react-query';
import type { ModelPricing, PricingResponse } from '../types/pricing';
import { logger } from '../utils/logger';

const LOG_CONTEXT = { component: 'useAIPricing' };

interface UseAIPricingOptions {
  enabled?: boolean;
  refetchInterval?: number; // milliseconds
}

export function useAIPricing(options: UseAIPricingOptions = {}) {
  const { enabled = true, refetchInterval = 1000 * 60 * 60 } = options; // Default: 1 hour
  const queryClient = useQueryClient();

  const query = useQuery<PricingResponse>({
    queryKey: ['ai-pricing'],
    queryFn: async () => {
      logger.info('🔄 Fetching AI pricing data...', LOG_CONTEXT);

      const response = await fetch('http://localhost:3001/api/ai-pricing');

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      logger.info('✅ AI pricing data loaded:', data.dataSource, LOG_CONTEXT);

      return data;
    },
    enabled,
    staleTime: 1000 * 60 * 60 * 24, // 24 hours
    refetchInterval, // Auto-refetch co godzinę
    refetchOnWindowFocus: false,
    retry: 3,
  });

  /**
   * Force refresh pricing data
   */
  const refresh = async () => {
    logger.info('🔄 Manually refreshing pricing data...', LOG_CONTEXT);

    try {
      const response = await fetch('http://localhost:3001/api/ai-pricing/refresh', {
        method: 'POST',
      });

      if (!response.ok) {
        throw new Error('Failed to refresh pricing');
      }

      // Invalidate cache and refetch
      await queryClient.invalidateQueries({ queryKey: ['ai-pricing'] });

      return true;
    } catch (error) {
      logger.error('❌ Error refreshing pricing:', LOG_CONTEXT, error as Error);
      return false;
    }
  };

  /**
   * Get pricing for a specific provider
   */
  const getPricingForProvider = (provider: 'openai' | 'anthropic' | 'google'): ModelPricing[] => {
    if (!query.data) return [];
    return query.data.models[provider] || [];
  };

  /**
   * Get pricing for a specific model by ID
   */
  const getPricingForModel = (modelId: string): ModelPricing | null => {
    if (!query.data) return null;

    const allModels = [
      ...query.data.models.openai,
      ...query.data.models.anthropic,
      ...query.data.models.google,
    ];

    return allModels.find(m => m.id === modelId) || null;
  };

  /**
   * Get all models sorted by cost (cheapest first)
   */
  const getModelsByCost = (): ModelPricing[] => {
    if (!query.data) return [];

    const allModels = [
      ...query.data.models.openai,
      ...query.data.models.anthropic,
      ...query.data.models.google,
    ];

    return allModels.sort((a, b) => a.costPer1000Responses - b.costPer1000Responses);
  };

  /**
   * Get cheapest model from each provider
   */
  const getCheapestByProvider = () => {
    if (!query.data) return null;

    return {
      openai: query.data.models.openai.reduce((min, model) =>
        model.costPer1000Responses < min.costPer1000Responses ? model : min
      ),
      anthropic: query.data.models.anthropic.reduce((min, model) =>
        model.costPer1000Responses < min.costPer1000Responses ? model : min
      ),
      google: query.data.models.google.reduce((min, model) =>
        model.costPer1000Responses < min.costPer1000Responses ? model : min
      ),
    };
  };

  return {
    // Data
    pricing: query.data,
    models: query.data?.models,
    isLoading: query.isLoading,
    isError: query.isError,
    error: query.error,

    // Metadata
    lastUpdated: query.data?.lastUpdated,
    dataSource: query.data?.dataSource,
    cacheExpiry: query.data?.cacheExpiry,
    nextUpdate: query.data?.nextUpdate,

    // Actions
    refresh,

    // Helper functions
    getPricingForProvider,
    getPricingForModel,
    getModelsByCost,
    getCheapestByProvider,
  };
}

