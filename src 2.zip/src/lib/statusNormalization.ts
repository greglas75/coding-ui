// ═══════════════════════════════════════════════════════════════
// 🎯 STATUS NORMALIZATION UTILITY
// ═══════════════════════════════════════════════════════════════
//
// This module provides a single source of truth for status values,
// ensuring consistency between database storage (lowercase) and
// UI display (friendly labels).

// ───────────────────────────────────────────────────────────────
// Canonical Database Values (lowercase)
// ───────────────────────────────────────────────────────────────

export const CANONICAL_STATUS = {
  UNCATEGORIZED: 'uncategorized',
  WHITELIST: 'whitelist',
  BLACKLIST: 'blacklist',
  CATEGORIZED: 'categorized',
  GLOBAL_BLACKLIST: 'global_blacklist',
  IGNORED: 'ignored',
  OTHER: 'other',
} as const;

export type CanonicalStatus = typeof CANONICAL_STATUS[keyof typeof CANONICAL_STATUS];

// ───────────────────────────────────────────────────────────────
// Display Labels (friendly names for UI)
// ───────────────────────────────────────────────────────────────

export const STATUS_LABELS: Record<CanonicalStatus, string> = {
  [CANONICAL_STATUS.UNCATEGORIZED]: 'Not Categorized',
  [CANONICAL_STATUS.WHITELIST]: 'Whitelist',
  [CANONICAL_STATUS.BLACKLIST]: 'Blacklist',
  [CANONICAL_STATUS.CATEGORIZED]: 'Categorized',
  [CANONICAL_STATUS.GLOBAL_BLACKLIST]: 'Global Blacklist',
  [CANONICAL_STATUS.IGNORED]: 'Ignored',
  [CANONICAL_STATUS.OTHER]: 'Other',
};

// ───────────────────────────────────────────────────────────────
// Reverse Mapping: Display Label -> Canonical Value
// ───────────────────────────────────────────────────────────────

const LABEL_TO_CANONICAL: Record<string, CanonicalStatus> = {
  'Not Categorized': CANONICAL_STATUS.UNCATEGORIZED,
  'Whitelist': CANONICAL_STATUS.WHITELIST,
  'Blacklist': CANONICAL_STATUS.BLACKLIST,
  'Categorized': CANONICAL_STATUS.CATEGORIZED,
  'Global Blacklist': CANONICAL_STATUS.GLOBAL_BLACKLIST,
  'Ignored': CANONICAL_STATUS.IGNORED,
  'Other': CANONICAL_STATUS.OTHER,
  // Also support lowercase and variations
  'uncategorized': CANONICAL_STATUS.UNCATEGORIZED,
  'whitelist': CANONICAL_STATUS.WHITELIST,
  'blacklist': CANONICAL_STATUS.BLACKLIST,
  'categorized': CANONICAL_STATUS.CATEGORIZED,
  'global_blacklist': CANONICAL_STATUS.GLOBAL_BLACKLIST,
  'global blacklist': CANONICAL_STATUS.GLOBAL_BLACKLIST,
  'ignored': CANONICAL_STATUS.IGNORED,
  'other': CANONICAL_STATUS.OTHER,
  // Support old quick_status values
  'Confirmed': CANONICAL_STATUS.WHITELIST,
  'Ignore': CANONICAL_STATUS.IGNORED,
};

// ───────────────────────────────────────────────────────────────
// Normalization Functions
// ───────────────────────────────────────────────────────────────

/**
 * Normalize a status value to its canonical database form
 *
 * Examples:
 * - 'Blacklist' -> 'blacklist'
 * - 'Global Blacklist' -> 'global_blacklist'
 * - 'blacklist' -> 'blacklist' (already normalized)
 *
 * @param value - Status value in any format
 * @returns Canonical lowercase status value
 */
export function normalizeStatus(value: string): CanonicalStatus {
  // Try direct lookup in mapping
  if (value in LABEL_TO_CANONICAL) {
    return LABEL_TO_CANONICAL[value];
  }

  // Try case-insensitive lookup
  const lowerValue = value.toLowerCase().trim();
  const key = Object.keys(LABEL_TO_CANONICAL).find(
    k => k.toLowerCase() === lowerValue
  );

  if (key) {
    return LABEL_TO_CANONICAL[key];
  }

  // Try replacing spaces with underscores
  const withUnderscore = lowerValue.replace(/\s+/g, '_');
  if (withUnderscore in LABEL_TO_CANONICAL) {
    return LABEL_TO_CANONICAL[withUnderscore];
  }

  // Default to lowercase with underscores as fallback
  return withUnderscore as CanonicalStatus;
}

/**
 * Normalize an array of status values
 *
 * @param values - Array of status values in any format
 * @returns Array of canonical lowercase status values
 */
export function normalizeStatuses(values: string[]): CanonicalStatus[] {
  return values.map(normalizeStatus);
}

/**
 * Get display label for a canonical status value
 *
 * @param canonicalValue - Canonical status value
 * @returns Friendly display label
 */
export function getStatusLabel(canonicalValue: string): string {
  // Normalize first in case we receive a non-canonical value
  const normalized = normalizeStatus(canonicalValue);
  return STATUS_LABELS[normalized] || canonicalValue;
}

/**
 * Get all available status options for dropdowns/filters
 *
 * @returns Array of objects with label and value
 */
export function getStatusOptions() {
  return Object.values(CANONICAL_STATUS).map(value => ({
    label: STATUS_LABELS[value],
    value,
  }));
}

/**
 * Get all display labels for use in UI components
 *
 * @returns Array of friendly display labels
 */
export function getStatusLabels(): string[] {
  return Object.values(STATUS_LABELS);
}

/**
 * Check if a value is a valid canonical status
 *
 * @param value - Value to check
 * @returns True if valid canonical status
 */
export function isValidStatus(value: string): value is CanonicalStatus {
  return Object.values(CANONICAL_STATUS).includes(value as CanonicalStatus);
}

