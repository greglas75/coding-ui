/**
 * Universal AI Categorizer
 *
 * Provides a unified interface for categorizing answers using different AI providers
 * (OpenAI, Claude, Gemini).
 */

import type { AiCodeSuggestion } from '../types';
import { logger } from '../utils/logger';
import type { AIProvider } from './aiProviderRouter';
import type { CategorizeRequest } from './openai';
import { categorizeAnswer as categorizeWithOpenAI } from './openai';

const LOG_CONTEXT = { component: 'aiCategorizer' };

/**
 * Categorizes an answer using the specified AI provider
 *
 * @param provider - AI provider to use ('openai', 'claude', 'gemini')
 * @param model - Model name for the provider
 * @param request - Categorization request with answer, codes, and context
 * @returns Array of AI code suggestions with confidence scores
 */
export async function categorizeWithProvider(
  provider: AIProvider,
  model: string,
  request: CategorizeRequest
): Promise<AiCodeSuggestion[]> {
  logger.info(`Categorizing with ${provider}/${model}`, LOG_CONTEXT);

  try {
    switch (provider) {
      case 'openai':
        return await categorizeWithOpenAI(request);

      case 'claude':
        return await categorizeWithClaude(model, request);

      case 'gemini':
        return await categorizeWithGemini(model, request);

      default:
        throw new Error(`Unknown AI provider: ${provider}`);
    }
  } catch (error) {
    logger.error(`Categorization failed for ${provider}/${model}`, LOG_CONTEXT, error as Error);
    throw error;
  }
}

/**
 * Categorizes using Claude/Anthropic
 */
async function categorizeWithClaude(
  model: string,
  request: CategorizeRequest
): Promise<AiCodeSuggestion[]> {
  const apiKey = localStorage.getItem('anthropic_api_key') || import.meta.env.VITE_ANTHROPIC_API_KEY;

  if (!apiKey) {
    logger.error('Anthropic API key not configured', LOG_CONTEXT);
    throw new Error('Anthropic API key not configured. Please add it in Settings.');
  }

  // Build the prompt
  const systemPrompt = buildPromptForCategorization(request);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000); // 30s timeout

  try {
    logger.info(`Calling Claude API with model ${model}`, LOG_CONTEXT);

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model,
        messages: [{ role: 'user', content: systemPrompt }],
        temperature: 0.3,
        max_tokens: 1024,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const errorText = await response.text().catch(() => 'Unknown error');
      throw new Error(`Claude API HTTP ${response.status}: ${errorText}`);
    }

    const data = await response.json();
    const content = data?.content?.[0]?.text;

    if (!content) {
      throw new Error('Empty response from Claude API');
    }

    // Parse JSON response
    const result = JSON.parse(content);

    // Validate and return suggestions
    if (!result.suggestions || !Array.isArray(result.suggestions)) {
      throw new Error('Invalid response format from Claude - missing suggestions array');
    }

    const validatedSuggestions = result.suggestions.map((suggestion: any) => ({
      code_id: String(suggestion.code_id || 'unknown'),
      code_name: String(suggestion.code_name || 'Unknown'),
      confidence: Math.max(0, Math.min(1, Number(suggestion.confidence) || 0)),
      reasoning: String(suggestion.reasoning || 'No reasoning provided'),
    }));

    logger.info(`Claude returned ${validatedSuggestions.length} suggestions`, LOG_CONTEXT);
    return validatedSuggestions;

  } catch (error) {
    clearTimeout(timeoutId);
    logger.error('Claude categorization failed', LOG_CONTEXT, error as Error);
    throw error;
  }
}

/**
 * Categorizes using Google Gemini
 */
async function categorizeWithGemini(
  model: string,
  request: CategorizeRequest
): Promise<AiCodeSuggestion[]> {
  const apiKey = localStorage.getItem('google_gemini_api_key') || import.meta.env.VITE_GOOGLE_GEMINI_API_KEY;

  if (!apiKey) {
    logger.error('Google Gemini API key not configured', LOG_CONTEXT);
    throw new Error('Google Gemini API key not configured. Please add it in Settings.');
  }

  // Build the prompt
  const systemPrompt = buildPromptForCategorization(request);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000); // 30s timeout

  try {
    logger.info(`Calling Gemini API with model ${model}`, LOG_CONTEXT);

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: systemPrompt }] }],
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 1024,
          },
        }),
        signal: controller.signal,
      }
    );

    clearTimeout(timeoutId);

    if (!response.ok) {
      const errorText = await response.text().catch(() => 'Unknown error');
      throw new Error(`Gemini API HTTP ${response.status}: ${errorText}`);
    }

    const data = await response.json();
    const content = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!content) {
      throw new Error('Empty response from Gemini API');
    }

    // Parse JSON response
    const result = JSON.parse(content);

    // Validate and return suggestions
    if (!result.suggestions || !Array.isArray(result.suggestions)) {
      throw new Error('Invalid response format from Gemini - missing suggestions array');
    }

    const validatedSuggestions = result.suggestions.map((suggestion: any) => ({
      code_id: String(suggestion.code_id || 'unknown'),
      code_name: String(suggestion.code_name || 'Unknown'),
      confidence: Math.max(0, Math.min(1, Number(suggestion.confidence) || 0)),
      reasoning: String(suggestion.reasoning || 'No reasoning provided'),
    }));

    logger.info(`Gemini returned ${validatedSuggestions.length} suggestions`, LOG_CONTEXT);
    return validatedSuggestions;

  } catch (error) {
    clearTimeout(timeoutId);
    logger.error('Gemini categorization failed', LOG_CONTEXT, error as Error);
    throw error;
  }
}

/**
 * Helper function to build the full prompt for categorization
 * Adapts the prompt building from openai.ts to work with all providers
 */
function buildPromptForCategorization(request: CategorizeRequest): string {
  let prompt = request.template;

  // Replace placeholders
  prompt = prompt.replace('{name}', request.categoryName);
  prompt = prompt.replace('{codes}', formatCodesForPrompt(request.codes));
  prompt = prompt.replace('{answer_lang}', request.context.language || 'unknown');
  prompt = prompt.replace('{country}', request.context.country || 'unknown');

  // Add answer section with both original and translation
  prompt += buildAnswerSection(request);

  // Add JSON format instructions if not present
  if (!prompt.includes('JSON')) {
    prompt += `\n\nIMPORTANT: You must respond with valid JSON in this exact format:
{
  "suggestions": [
    {
      "code_id": "1",
      "code_name": "Nike",
      "confidence": 0.95,
      "reasoning": "User explicitly mentioned 'nike' in their response"
    }
  ]
}

Rules:
- Return 1-3 suggestions, ordered by confidence (highest first)
- confidence must be a number between 0.0 and 1.0
- Only suggest codes that are relevant to the answer
- If uncertain, use lower confidence scores
- Always provide clear reasoning for each suggestion`;
  }

  return prompt;
}

/**
 * Format codes array for the prompt
 */
function formatCodesForPrompt(codes: Array<{ id: string; name: string }>): string {
  return codes.map((code, idx) => `${idx + 1}. ${code.name} (ID: ${code.id})`).join('\n');
}

/**
 * Build answer section with both original and translation
 */
function buildAnswerSection(request: CategorizeRequest): string {
  let section = `\n\n=== ANSWER INFORMATION ===\n\n`;

  section += `Original Answer (${request.context.language || 'unknown'}): "${request.answer}"`;

  if (request.answerTranslation) {
    section += `\nEnglish Translation: "${request.answerTranslation}"`;
  }

  section += `\n\n=== INSTRUCTIONS ===
- Analyze BOTH the original answer and English translation (if provided)
- The original may contain brand names in local spelling
- The translation helps understand context and intent
- Consider information from BOTH languages for maximum accuracy
- Brand names like "Nike", "Colgate", "Coca-Cola" may appear in either version
- If brand name appears in original language, it's usually more reliable
- Use redundancy between languages to increase confidence scores
- Generic terms without specific brands should have lower confidence`;

  return section;
}

/**
 * Gets estimated cost for a categorization request
 *
 * @param provider - AI provider
 * @param model - Model name
 * @param inputLength - Approximate input length in characters
 * @param outputLength - Approximate output length in characters
 * @returns Estimated cost in USD
 */
export function estimateCategorizationCost(
  provider: AIProvider,
  model: string,
  inputLength: number,
  outputLength: number = 500
): number {
  // Rough estimate: 1 token ≈ 4 characters
  const inputTokens = Math.ceil(inputLength / 4);
  const outputTokens = Math.ceil(outputLength / 4);
  const totalTokens = inputTokens + outputTokens;

  // Cost per 1M tokens (as of October 2025)
  const costs: Record<string, number> = {
    // OpenAI
    'gpt-4o': 5.0,
    'gpt-4o-mini': 0.15,
    'gpt-4.1': 10.0,
    'gpt-5': 15.0,
    'o1': 15.0,
    'o1-mini': 1.0,
    'gpt-4.1-nano': 0.075,

    // Claude
    'claude-sonnet-4.5-20250929': 3.0,
    'claude-opus-4-20250522': 15.0,
    'claude-3-5-sonnet-20241022': 3.0,
    'claude-3-5-haiku-20241022': 0.8,

    // Gemini
    'gemini-2.0-pro-experimental': 2.5,
    'gemini-2.0-flash': 0.075,
    'gemini-1.5-pro': 1.25,
    'gemini-1.5-flash': 0.075,
  };

  const costPer1M = costs[model] || 5.0; // Default to mid-range cost
  return (totalTokens / 1_000_000) * costPer1M;
}

