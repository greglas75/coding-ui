/**
 * AI Provider Router
 *
 * Determines which AI provider (OpenAI, Claude, Gemini) to use for categorization
 * based on category settings and localStorage fallbacks.
 */

export type AIProvider = 'openai' | 'claude' | 'gemini';

export interface ProviderConfig {
  provider: AIProvider;
  model: string;
}

/**
 * Selects the appropriate AI provider and model for a given category
 *
 * Priority:
 * 1. Category's openai_model (if set)
 * 2. Category's claude_model (if set)
 * 3. Category's gemini_model (if set)
 * 4. Fallback to localStorage.openai_model
 * 5. Ultimate fallback to 'gpt-4o-mini'
 *
 * @param category - Category object with optional model overrides
 * @returns Provider configuration with provider name and model
 */
export function selectProviderForCategory(category: {
  openai_model?: string | null;
  claude_model?: string | null;
  gemini_model?: string | null;
}): ProviderConfig {
  // Priority 1: OpenAI model
  if (category.openai_model) {
    return {
      provider: 'openai',
      model: category.openai_model,
    };
  }

  // Priority 2: Claude model
  if (category.claude_model) {
    return {
      provider: 'claude',
      model: category.claude_model,
    };
  }

  // Priority 3: Gemini model
  if (category.gemini_model) {
    return {
      provider: 'gemini',
      model: category.gemini_model,
    };
  }

  // Fallback to localStorage settings
  const openaiModel = localStorage.getItem('openai_model');
  if (openaiModel) {
    return {
      provider: 'openai',
      model: openaiModel,
    };
  }

  const claudeModel = localStorage.getItem('anthropic_model');
  if (claudeModel) {
    return {
      provider: 'claude',
      model: claudeModel,
    };
  }

  const geminiModel = localStorage.getItem('google_gemini_model');
  if (geminiModel) {
    return {
      provider: 'gemini',
      model: geminiModel,
    };
  }

  // Ultimate fallback
  return {
    provider: 'openai',
    model: 'gpt-4o-mini',
  };
}

/**
 * Gets the display name for a provider
 */
export function getProviderDisplayName(provider: AIProvider): string {
  const names: Record<AIProvider, string> = {
    openai: 'OpenAI',
    claude: 'Claude (Anthropic)',
    gemini: 'Google Gemini',
  };
  return names[provider];
}

/**
 * Validates if a model name is valid for a given provider
 */
export function isValidModelForProvider(provider: AIProvider, model: string): boolean {
  const validModels: Record<AIProvider, string[]> = {
    openai: ['gpt-4o', 'gpt-4o-mini', 'gpt-4.1', 'gpt-5', 'o1', 'o1-mini', 'gpt-4.1-nano'],
    claude: [
      'claude-sonnet-4.5-20250929',
      'claude-opus-4-20250522',
      'claude-3-5-sonnet-20241022',
      'claude-3-5-haiku-20241022',
    ],
    gemini: [
      'gemini-2.0-pro-experimental',
      'gemini-2.0-flash',
      'gemini-1.5-pro',
      'gemini-1.5-flash',
    ],
  };

  return validModels[provider]?.includes(model) ?? false;
}

