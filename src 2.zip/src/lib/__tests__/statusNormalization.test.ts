// Example tests for statusNormalization
// Run with: npm test statusNormalization

import {
    CANONICAL_STATUS,
    getStatusLabel,
    normalizeStatus,
    normalizeStatuses
} from '../statusNormalization';

describe('Status Normalization', () => {
  describe('normalizeStatus', () => {
    it('normalizes capitalized display names', () => {
      expect(normalizeStatus('Blacklist')).toBe('blacklist');
      expect(normalizeStatus('Global Blacklist')).toBe('global_blacklist');
      expect(normalizeStatus('Whitelist')).toBe('whitelist');
    });

    it('handles already normalized values', () => {
      expect(normalizeStatus('blacklist')).toBe('blacklist');
      expect(normalizeStatus('global_blacklist')).toBe('global_blacklist');
    });

    it('handles variations with spaces', () => {
      expect(normalizeStatus('global blacklist')).toBe('global_blacklist');
      expect(normalizeStatus('Global  Blacklist')).toBe('global_blacklist');
    });

    it('handles old quick_status values', () => {
      expect(normalizeStatus('Confirmed')).toBe('whitelist');
      expect(normalizeStatus('Ignore')).toBe('ignored');
    });
  });

  describe('normalizeStatuses', () => {
    it('normalizes arrays of statuses', () => {
      const input = ['Blacklist', 'Global Blacklist', 'Whitelist'];
      const expected = ['blacklist', 'global_blacklist', 'whitelist'];
      expect(normalizeStatuses(input)).toEqual(expected);
    });
  });

  describe('getStatusLabel', () => {
    it('returns friendly display labels', () => {
      expect(getStatusLabel('blacklist')).toBe('Blacklist');
      expect(getStatusLabel('global_blacklist')).toBe('Global Blacklist');
      expect(getStatusLabel('whitelist')).toBe('Whitelist');
    });

    it('normalizes input before getting label', () => {
      expect(getStatusLabel('Blacklist')).toBe('Blacklist');
      expect(getStatusLabel('Global Blacklist')).toBe('Global Blacklist');
    });
  });

  describe('CANONICAL_STATUS', () => {
    it('exports correct canonical values', () => {
      expect(CANONICAL_STATUS.BLACKLIST).toBe('blacklist');
      expect(CANONICAL_STATUS.GLOBAL_BLACKLIST).toBe('global_blacklist');
      expect(CANONICAL_STATUS.WHITELIST).toBe('whitelist');
    });
  });
});

