"""Tests package for codeframe generation service."""
