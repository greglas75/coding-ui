"""Services package for codeframe generation pipeline."""
